package com.linroid.ketch.api

internal const val KETCH_BUILD_VERSION = "0.0.2-dev1"
internal const val KETCH_BUILD_REVISION = "4c817f5"
