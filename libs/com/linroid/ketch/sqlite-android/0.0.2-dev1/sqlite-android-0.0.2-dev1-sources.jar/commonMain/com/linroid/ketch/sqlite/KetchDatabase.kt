package com.linroid.ketch.sqlite

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.linroid.ketch.sqlite.sqlite.newInstance
import com.linroid.ketch.sqlite.sqlite.schema
import kotlin.Unit

public interface KetchDatabase : Transacter {
  public val taskRecordsQueries: TaskRecordsQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = KetchDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): KetchDatabase = KetchDatabase::class.newInstance(driver)
  }
}
