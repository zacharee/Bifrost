package com.linroid.ketch.sqlite.sqlite

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.linroid.ketch.sqlite.KetchDatabase
import com.linroid.ketch.sqlite.TaskRecordsQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<KetchDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = KetchDatabaseImpl.Schema

internal fun KClass<KetchDatabase>.newInstance(driver: SqlDriver): KetchDatabase = KetchDatabaseImpl(driver)

private class KetchDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    KetchDatabase {
  override val taskRecordsQueries: TaskRecordsQueries = TaskRecordsQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 3

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS task_records (
          |  task_id TEXT NOT NULL PRIMARY KEY,
          |  request_json TEXT NOT NULL,
          |  output_path TEXT,
          |  state TEXT NOT NULL DEFAULT 'PENDING',
          |  total_bytes INTEGER NOT NULL DEFAULT -1,
          |  source_type TEXT,
          |  source_resume_state_json TEXT,
          |  segments_json TEXT,
          |  created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000),
          |  updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000),
          |  error_json TEXT
          |)
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    private fun migrateInternal(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
    ): QueryResult.Value<Unit> {
      if (oldVersion <= 1 && newVersion > 1) {
        driver.execute(null, """
            |CREATE TABLE task_records_new (
            |  task_id TEXT NOT NULL PRIMARY KEY,
            |  request_json TEXT NOT NULL,
            |  output_path TEXT,
            |  state TEXT NOT NULL DEFAULT 'PENDING',
            |  total_bytes INTEGER NOT NULL DEFAULT -1,
            |  accept_ranges INTEGER,
            |  etag TEXT,
            |  last_modified TEXT,
            |  segments_json TEXT,
            |  created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000),
            |  updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000),
            |  error_json TEXT
            |)
            """.trimMargin(), 0)
        driver.execute(null, """
            |INSERT INTO task_records_new (
            |  task_id, request_json, output_path, state,
            |  total_bytes, accept_ranges, etag, last_modified,
            |  segments_json, created_at, updated_at
            |)
            |SELECT
            |  task_id, request_json, output_path, state,
            |  total_bytes, accept_ranges, etag, last_modified,
            |  segments_json, created_at, updated_at
            |FROM task_records
            """.trimMargin(), 0)
        driver.execute(null, "DROP TABLE task_records", 0)
        driver.execute(null, "ALTER TABLE task_records_new RENAME TO task_records", 0)
      }
      if (oldVersion <= 2 && newVersion > 2) {
        driver.execute(null, """
            |CREATE TABLE task_records_new (
            |  task_id TEXT NOT NULL PRIMARY KEY,
            |  request_json TEXT NOT NULL,
            |  output_path TEXT,
            |  state TEXT NOT NULL DEFAULT 'PENDING',
            |  total_bytes INTEGER NOT NULL DEFAULT -1,
            |  source_type TEXT,
            |  source_resume_state_json TEXT,
            |  segments_json TEXT,
            |  created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000),
            |  updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000),
            |  error_json TEXT
            |)
            """.trimMargin(), 0)
        driver.execute(null, """
            |INSERT INTO task_records_new (
            |  task_id, request_json, output_path, state,
            |  total_bytes, segments_json, created_at, updated_at, error_json
            |)
            |SELECT
            |  task_id, request_json, output_path, state,
            |  total_bytes, segments_json, created_at, updated_at, error_json
            |FROM task_records
            """.trimMargin(), 0)
        driver.execute(null, "DROP TABLE task_records", 0)
        driver.execute(null, "ALTER TABLE task_records_new RENAME TO task_records", 0)
      }
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> {
      var lastVersion = oldVersion

      callbacks.filter { it.afterVersion in oldVersion until newVersion }
      .sortedBy { it.afterVersion }
      .forEach { callback ->
        migrateInternal(driver, oldVersion = lastVersion, newVersion = callback.afterVersion + 1)
        callback.block(driver)
        lastVersion = callback.afterVersion + 1
      }

      if (lastVersion < newVersion) {
        migrateInternal(driver, lastVersion, newVersion)
      }
      return QueryResult.Unit
    }
  }
}
