package com.linroid.ketch.sqlite

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class TaskRecordsQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> load(task_id: String, mapper: (
    task_id: String,
    request_json: String,
    output_path: String?,
    state: String,
    total_bytes: Long,
    source_type: String?,
    source_resume_state_json: String?,
    segments_json: String?,
    created_at: Long,
    updated_at: Long,
    error_json: String?,
  ) -> T): Query<T> = LoadQuery(task_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getString(3)!!,
      cursor.getLong(4)!!,
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getString(10)
    )
  }

  public fun load(task_id: String): Query<Task_records> = load(task_id, ::Task_records)

  public fun <T : Any> loadAll(mapper: (
    task_id: String,
    request_json: String,
    output_path: String?,
    state: String,
    total_bytes: Long,
    source_type: String?,
    source_resume_state_json: String?,
    segments_json: String?,
    created_at: Long,
    updated_at: Long,
    error_json: String?,
  ) -> T): Query<T> = Query(1_376_148_221, arrayOf("task_records"), driver, "TaskRecords.sq", "loadAll", "SELECT task_records.task_id, task_records.request_json, task_records.output_path, task_records.state, task_records.total_bytes, task_records.source_type, task_records.source_resume_state_json, task_records.segments_json, task_records.created_at, task_records.updated_at, task_records.error_json FROM task_records") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getString(3)!!,
      cursor.getLong(4)!!,
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getString(10)
    )
  }

  public fun loadAll(): Query<Task_records> = loadAll(::Task_records)

  /**
   * @return The number of rows updated.
   */
  public fun insertOrIgnore(
    task_id: String,
    request_json: String,
    output_path: String?,
    state: String,
    total_bytes: Long,
    source_type: String?,
    source_resume_state_json: String?,
    segments_json: String?,
    error_json: String?,
  ): QueryResult<Long> {
    val result = driver.execute(-1_971_911_412, """
        |INSERT OR IGNORE INTO task_records(
        |  task_id, request_json, output_path, state,
        |  total_bytes, source_type, source_resume_state_json,
        |  segments_json, error_json
        |) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 9) {
          var parameterIndex = 0
          bindString(parameterIndex++, task_id)
          bindString(parameterIndex++, request_json)
          bindString(parameterIndex++, output_path)
          bindString(parameterIndex++, state)
          bindLong(parameterIndex++, total_bytes)
          bindString(parameterIndex++, source_type)
          bindString(parameterIndex++, source_resume_state_json)
          bindString(parameterIndex++, segments_json)
          bindString(parameterIndex++, error_json)
        }
    notifyQueries(-1_971_911_412) { emit ->
      emit("task_records")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun update(
    request_json: String,
    output_path: String?,
    state: String,
    total_bytes: Long,
    source_type: String?,
    source_resume_state_json: String?,
    segments_json: String?,
    error_json: String?,
    task_id: String,
  ): QueryResult<Long> {
    val result = driver.execute(718_707_815, """
        |UPDATE task_records SET
        |  request_json = ?,
        |  output_path = ?,
        |  state = ?,
        |  total_bytes = ?,
        |  source_type = ?,
        |  source_resume_state_json = ?,
        |  segments_json = ?,
        |  error_json = ?,
        |  updated_at = CAST(strftime('%s', 'now') AS INTEGER) * 1000
        |WHERE task_id = ?
        """.trimMargin(), 9) {
          var parameterIndex = 0
          bindString(parameterIndex++, request_json)
          bindString(parameterIndex++, output_path)
          bindString(parameterIndex++, state)
          bindLong(parameterIndex++, total_bytes)
          bindString(parameterIndex++, source_type)
          bindString(parameterIndex++, source_resume_state_json)
          bindString(parameterIndex++, segments_json)
          bindString(parameterIndex++, error_json)
          bindString(parameterIndex++, task_id)
        }
    notifyQueries(718_707_815) { emit ->
      emit("task_records")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun remove(task_id: String): QueryResult<Long> {
    val result = driver.execute(622_943_266, """DELETE FROM task_records WHERE task_id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, task_id)
        }
    notifyQueries(622_943_266) { emit ->
      emit("task_records")
    }
    return result
  }

  private inner class LoadQuery<out T : Any>(
    public val task_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("task_records", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("task_records", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_877_571_588, """SELECT task_records.task_id, task_records.request_json, task_records.output_path, task_records.state, task_records.total_bytes, task_records.source_type, task_records.source_resume_state_json, task_records.segments_json, task_records.created_at, task_records.updated_at, task_records.error_json FROM task_records WHERE task_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, task_id)
    }

    override fun toString(): String = "TaskRecords.sq:load"
  }
}
