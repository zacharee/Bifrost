package com.linroid.ketch.sqlite

import kotlin.Long
import kotlin.String

public data class Task_records(
  public val task_id: String,
  public val request_json: String,
  public val output_path: String?,
  public val state: String,
  public val total_bytes: Long,
  public val source_type: String?,
  public val source_resume_state_json: String?,
  public val segments_json: String?,
  public val created_at: Long,
  public val updated_at: Long,
  public val error_json: String?,
)
